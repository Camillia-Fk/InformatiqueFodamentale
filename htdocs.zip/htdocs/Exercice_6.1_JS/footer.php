<footer>
    <p> Image fournies par <a href="https://fr.freepik.com/photos-gratuite/fond-ecran-abstrait-nebuleuse-ultra-detaille-4_39994508.htm#query=espace&position=0&from_view=keyword&track=sph&uuid=54b5cb37-b88c-4be0-93cd-9099bb9284cc"
        target="_blank">freepik.com,</a>
        <a href="https://www.pxfuel.com/en/desktop-wallpaper-ifzfs" target="_blank"> pxfuel.com,
        <a href="https://fr.wikipedia.org/wiki/Soleil" target="_blank"> wikipedia.org,</a>
        <a href="https://www.sciencesetavenir.fr/espace/voie-lactee/miguel-montarges-au-sujet-de-l-etoile-betelgeuse-pour-etre-honnete-on-ne-sait-pas-vraiment-ce-qu-il-se-passe_141675" 
            target="_blank"> sciencesetavenir.fr,</a>
        <a href= "https://www.pinterest.fr/pin/695876579917719056/" target="_blank"> pinterest.fr</a>
    </p>
</footer>