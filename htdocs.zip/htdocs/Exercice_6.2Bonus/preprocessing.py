"""
J'ai eu besoin de Pandas pour effectuer les prétraitement.
J'ai découvert ce package dans le dernier chapitre de GIL.
La majorité des informations que j'ai utilisé ici viennent des tutoriels officiels de Pandas.
Un peu de StackOverflow.
Entre autres.
"""
import pandas as pd

# Lecture des données au format JSON
# Elles sont mal lues par pandas, la colonne fields contient des dictionnaires
# Ces derniers auraient du être des colonnes
df = pd.read_json("fr-esr-atlas_regional-effectifs-d-etudiants-inscrits.json")
# Transformation des donneés brutes contenues dans fields en series (lignes de données)
# La méthode apply se charge de la concaténation des séries pour donner un DataFrame propre en sortie
# Tous les éléments de cette colonne n'ont pas forcément la même structure (des dictionnaires ayant des clés différentes)
# Apply se charge de la mise en forme, des NaN sont mis là où le champs correspondant est absent du dictionnaire
# A la fin, toutes les données ont toutes les colonnes communes avec potentiellement des NaN si à la base une colonne n'était pas présente.
df2 = df["fields"].apply(pd.Series)
# On se concentre sur le nombre d'admis par rentrée et par type d'établissement de formation.
# PS : Le raisonnement suivant est similaire à SQL, la documentation officielle de Pandas consacre un tutoriel aux parallèles entre Pandas et SQL.
# On regroupe les lignes par rentrée scolaire, on extrait la colonne cible et on compte le nombre des différentes valeurs
# Unstack permet de transformer une série avec de multiples indices en un DataFrame

df3 = df2.groupby("rentree")["rgp_formations_ou_etablissements"].value_counts().unstack()

# On reformate les données pour que l'application streamlit les reçoive propres et en ordre.
df3.reset_index(inplace=True)
df3["rentree"] = df3["rentree"].astype(int)
df3.set_index("rentree", inplace=True)
df3.sort_index(inplace=True)
# Le DataFrame résultant est enregistré sous format json
df3.to_json('processed_data.json')