"""
Code de l'application streamlit
"""

# La lib plotly permet d'avoir des graphiques intéractifs bien plus jolis que matplotlib.
import plotly.express as px
import pandas as pd
import streamlit as st

from plotly1 import plotly_events1, plotly_events2

# Lecture de "processed_data.json" et mise de son contenu dans df
df = pd.read_json("processed_data.json")

# Titre de la page web générée par streamlit
st.title("Mon application qui tue.")

# Message pour l'utilisateur lui suggérant les selections valides
st.write("Quelle année voulez-vous afficher parmis les années suivantes : " + ", ".join(df.index.to_series().apply(str).to_list()) + " ?")
# Lecture de la saisie
year = int(st.text_input("Année :", value="2001"))

# Affichage du graphique à barres 
fig = px.bar(df.loc[year], title="Mon graphique")
fig.update_yaxes(range=[0, df.max().max()])
value = plotly_events1(fig)

# Message pour l'utilisateur lui résumant les données que représente l'élément du graphique cliqué
st.write("Détails de la barre sélectionnée :", value)

# Message pour l'utilisateur lui suggérant les selections valides
st.write("Quel type d'établissements voulez-vous afficher parmis les types d'établissements suivants :")
for s in df.columns:
    st.write(s)

# Lecture de la saisie
etablissement = str(st.text_input("Type d'établissement :", value="Écoles supérieures art et culture"))

# Affichage du graphique à barres 
fig = px.bar(df.T.loc[etablissement], title="Mon graphique 2")
fig.update_yaxes(range=[0, df.T.loc[etablissement].max()])
value = plotly_events2(fig)

# Message pour l'utilisateur lui résumant les données que représente l'élément du graphique cliqué
st.write("Détails de la barre sélectionnée :", value)
