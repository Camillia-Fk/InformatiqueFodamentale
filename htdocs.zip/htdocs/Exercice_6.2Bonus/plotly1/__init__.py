"""
Ce package est fortement inspiré du tutoriel youtube de ... et de son GitHub
"""

from plotly.graph_objects import Figure
import streamlit.components.v1 as components

_component_func = components.declare_component(
    "plotly1",
    path="./plotly1"
)

def plotly_events1(fig: Figure):
    """
    Permet d'extraire des inforations sur la sélection dans plotly. Réagit aux clics.
    """
    # spec = json.dumps(fig, cls=PlotlyJSONEncoder)
    spec = fig.to_json()
    component_value = _component_func(spec = spec, default = None)
    if component_value is None:
        return ""
    etablissement = component_value[0]["x"]
    nombre_inscrits = component_value[0]["y"]
    return f"Il y a eu {nombre_inscrits} inscrits dans {etablissement} lors de cette année !"

def plotly_events2(fig: Figure):
    """
    Permet d'extraire des inforations sur la sélection dans plotly. Réagit aux clics.
    """
    if fig is None:
        return ""
    # spec = json.dumps(fig, cls=PlotlyJSONEncoder)
    spec = fig.to_json()
    component_value = _component_func(spec = spec, default = None)
    if component_value is None:
        return ""
    annee = component_value[0]["x"]
    nombre_inscrits = component_value[0]["y"]
    return f"Il y a eu {nombre_inscrits} inscrits lors de l'année {annee} dans ce type d'établissements !"
