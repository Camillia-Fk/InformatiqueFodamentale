#!/bin/bash

# Ce code a pour but de contourner le prétraitement des données
# En ne l'executant que si nécessaire
# Et en évitant de le mettre dans l'application streamlit
# Car à chaque interaction, cette dernière relancera tous les traitements
# C'est très chronophage.

pip install plotly
pip install streamlit

# Définir le nom du fichier à vérifier (il est supposé contenir les données prétraitées)
FILE="processed_data.json"

# Vérifier si le fichier existe dans le répertoire courant
if [ -f "$FILE" ]; then
    # Si oui, on ne lance pas le prétraitement
    echo "$FILE existe."
    # Lancer l'application streamlit
    streamlit run streamlit_app.py
else
    # Sinon, le prétraitement est lancé
    echo "$FILE n'existe pas."
    # Exécuter la commande de prétraitement
    python3 preprocessing.py
    # Lancer l'application streamlit
    streamlit run streamlit_app.py
fi